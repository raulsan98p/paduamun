<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" href="images/sap/logico.ico">
	<link rel="stylesheet" href="fonts/stylesheet.css">
	<link rel="stylesheet" href="css/swiper-bundle.min.css">
	<link rel="stylesheet" href="css/magnific-popup.min.css">
	<link rel="stylesheet" href="css/animate.min.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<title>PADUAMUN 2024</title>
</head>

<body>

	<div class="modal-form mfp-hide mfp-with-anim" id="modal-form">

		<div class="modal-form-head">
			<div class="modal-form-logo">
				<img src="images/sap/header-logo.png" alt="logomun">
			</div>
			<div class="modal-form-close">
				<img src="images/close.svg" alt="Close">
			</div>
		</div>

	</div>

	<div class="go-up">
		<a href="#">
			<img src="images/arrow-up.svg" alt="Go up">
		</a>
	</div>
	
	<header class="site-header">

		<div class="header-top">
			<div class="container">
				<div class="header-row">

					<!-- Header top mobile START -->
					<div class="header-mobile-logo">
						<a href="#">
							<img src="images/sap/header-logo.png" alt="Construction">
						</a>
					</div>

					<div class="hamburger">
						<span></span>
						<span></span>
					</div>
					<!-- Header top mobile END -->

                    <!-- AQUI COMIENZA EL NAV BAR PRINCIPAL  -->
					<div class="header-desc">#paduamun2024</div>
					<div class="header-right">
						<div class="header-info">
							<img src="images/location.svg" alt="located">
							<span> <a type="botton" href="https://maps.app.goo.gl/WCwoZ2ZmfK9EsKjs8" target="_blank" style="text-decoration: none" >1204 Jimenez Pimentel St. Tarapoto, PE</a></span>
						</div>
						<a href="tel:+51950706191" class="header-info">
							<img src="images/phone.svg" alt="colegiomobile">
							<span>+51 950 706 191</span>
						</a>

						<div class="header-social">
							<a href="https://www.facebook.com/paduatarapoto" target="_blank">
								<i class="fa fa-facebook" style="font-size:36px"></i>
							</a>
							<a href="https://www.instagram.com/paduamodelun/" target="_blank">
								<i class="fa fa-instagram" style="font-size:36px"></i>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
         <!-- AQUI COMIENZA EL NAV FLOTANTE  -->
		<div class="header-bottom">
			<div class="container">
				<div class="header-bottom-row">
					<div class="header-logo">
						<a href="<?php echo e(route('admin')); ?>">
							<img src="images/sap/header-logo.png" alt="logomun">
						</a>
					</div>

					<nav class="header-nav">
						<ul>
							<li><a class="anchor-link" href="#s-about">About us</a></li>
							<li><a class="anchor-link" href="#s-services">Committees</a></li>
							<li><a class="anchor-link" href="#s-gallery">Gallery</a></li>
							<li><a class="anchor-link" href="#s-team">Our teachers</a></li>
							<li><a class="anchor-link" href="#s-testimonials">Testimonials</a></li>
							<li><a class="anchor-link" href="#s-contact">Contact</a></li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
                            <!-- AQUI TERMINA EL NAVBAR PRINCIPAL  -->

		<!-- Header mobile START -->
		<div class="header-mobile-wrap">
			<nav class="header-mobile-nav">
				<ul>
					<li><a class="anchor-link" href="#s-about">About us</a></li>
					<li><a class="anchor-link" href="#s-services">Committees</a></li>
					<li><a class="anchor-link" href="#s-gallery">Gallery</a></li>
					<li><a class="anchor-link" href="#s-team">Our teachers</a></li>
					<li><a class="anchor-link" href="#s-testimonials">Testimonials</a></li>
					<li><a class="anchor-link" href="#s-contact">Contact</a></li>
				</ul>
			</nav>

			<div class="header-mobile-info">
				<img src="images/location.svg" alt="locate">
				<span><a type="botton" href="https://maps.app.goo.gl/WCwoZ2ZmfK9EsKjs8" target="_blank" style="text-decoration: none" >1204 Jimenez Pimentel St. Tarapoto, PE</a></span>
			</div>
			<a href="tel:+51950706191" class="header-mobile-info">
				<img src="images/phone.svg" alt="colegiomobile">
				<span>+51950706191</span>
			</a>

			<div class="header-mobile-social">
					<a href="https://www.facebook.com/paduatarapoto" target="_blank">
						<i class="fa fa-facebook" style="font-size:36px"></i>
					</a>
					<a href="https://www.instagram.com/paduamodelun/" target="_blank">
						<i class="fa fa-instagram" style="font-size:36px"></i>
					</a>
			</div>
		</div>
		<!-- Header mobile END -->

	</header>

		<!-- CARRUSEL SECTION INICIO -->
	<section class="s-banner">
		
		<div class="swiper banner-swiper">
			
			<div class="swiper-wrapper">
				<div class="swiper-slide" style="background-image: url(images/sap/d1.png)">
					<div class="banner-content">
						<div class="banner-subtitle wow fadeIn " data-wow-delay="0.1s"><strong>San Antonio de Padua</strong></div>
						<h2 class="banner-title wow fadeIn" data-wow-delay="0.2s"><strong>Making leaders</strong></h2>
					</div>
				</div>
				<div class="swiper-slide" style="background-image: url(images/sap/d2.jpg)">
					<div class="banner-content">
						<div class="banner-subtitle wow fadeIn"><strong>San Antonio de Padua</strong></div>
						<h2 class="banner-title"><strong>We enjoy working together</strong></h2>
					</div>
				</div>
				<div class="swiper-slide" style="background-image: url(images/sap/d3.jpg)">
					<div class="banner-content">
						<div class="banner-subtitle"><strong>San Antonio de Padua</strong></div>
						<h2 class="banner-title"><strong>Let your dreams come true</strong></h2>
					</div>
				</div>
			</div>

			<div class="swiper-pagination wow fadeInUp" data-wow-delay="0.5s"></div>
			
			<div class="container">
				<div class="swiper-button-prev"></div>
				<div class="swiper-button-next"></div>
			</div>
		
		</div>

	</section>
<!-- CARRUSEL SECTION FIN -->

	<section class="s-about" id="s-about">
		<div class="container">

			<div class="about-row">
				<div class="about-left">
					<h2 class="def-title wow fadeInLeft" data-wow-delay="0.2s">About this team</h2>
					<div class="def-desc wow fadeInLeft" data-wow-delay="0.3s">
						<center><strong>Paduamun2024</strong> is a full service building design company with a simple and unique design and construction philosophy. We believe that one building designer will take the job from concept on paper to implementation on your site. Cause; by doing this, you can communicate and work with one person, where you can share your thoughts and ideas to bring them to life in collaboration.
					</div></center>
				</div>
	
				<div class="about-right">
					<img src="images/sap/logomun.png" alt="logomun" class="wow fadeIn" data-wow-delay="0.5s">
				</div>
			</div>

		</div>
	</section>


	<section class="s-numbers">
		<div class="container">
			<div class="numbers-row num-scroll">

				<div class="numbers-left">
					<h2 class="def-title color-white wow fadeInLeft" data-wow-delay="0.2s">This year participating <br> in numbers</h2>
					<div class="def-desc wow fadeInLeft" data-wow-delay="0.3s">
						This year we have a plenty of students around the country visiting us for this MUN session.
					</div>
				</div>

				<div class="numbers-right">
					<div class="numbers-item">
						<div class="numbers-num num-js" data-count="15066">0</div>
						<div class="numbers-desc">
							Happy <br>
							Students
						</div>
					</div>
					<div class="numbers-item">
						<div class="numbers-num num-js" data-count="24">0</div>
						<div class="numbers-desc">
							Years of work experience
						</div>
					</div>
					<div class="numbers-item">
						<div class="numbers-num num-js" data-count="30">0</div>
						<div class="numbers-desc">
							Awards
						</div>
					</div>
					<div class="numbers-item">
						<div class="numbers-num num-js" data-count="385">0</div>
						<div class="numbers-desc">
							Realized <br>
							projects
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>

<!-- CCOMITÉS INICIO -->
	<section class="s-services" id="s-services">
	<h2 class="center-title wow fadeIn" data-wow-delay="0.1s">Our committees this year</h2>
			
				<div class="grid-container">
     				<div class="grid-item wow fadeIn" data-wow-delay="0.2s" style="background-image: url('images/sap/co1.png')"></div>
					<div class="grid-item wow fadeIn" data-wow-delay="0.3s" style="background-image: url('images/sap/co2.png');"></div>
					<div class="grid-item wow fadeIn" data-wow-delay="0.4s" style="background-image: url('images/sap/co3.png');"></div>
					<div class="grid-item wow fadeIn" data-wow-delay="0.5s" style="background-image: url('images/sap/co4.png');"></div>
					<div class="grid-item wow fadeIn" data-wow-delay="0.6s" style="background-image: url('images/sap/co5.png');"></div>
					<div class="grid-item wow fadeIn" data-wow-delay="0.7s" style="background-image: url('images/sap/co6.png');"></div>
					<div class="grid-item wow fadeIn" data-wow-delay="0.8s" style="background-image: url('images/sap/co7.png');"></div>
					<div class="grid-item wow fadeIn" data-wow-delay="0.9s" style="background-image:url('images/sap/co8.png');"></div>
					<div class="grid-item wow fadeIn" data-wow-delay="0.10s" style="background-image: url('images/sap/co9.png');"></div>
					<div class="grid-item wow fadeIn" data-wow-delay="0.11s" style="background-image: url('images/sap/co10.png');"></div>
					<div class="grid-item wow fadeIn" data-wow-delay="0.12s" style="background-image: url('images/sap/co11.png');"></div>
				</div>
			
		
	</section>

<!-- COMITÉS FIN -->

<!-- AQUI COMIENZA LA GALERÍA 1 -->
	<section class="s-gallery" id="s-gallery">
		<div class="container">
		<h1 class="center-title wow fadeIn" data-wow-delay="0.1s">GALLERY</h1>
			<h2 class="center-title wow fadeIn" data-wow-delay="0.1s">NEWTONMUN - LIMA 2024</h2>

			<div class="gallery-wrap">
				<a href="images/sap/num1.jpg" class="gallery-item wow fadeIn" data-effect="mfp-zoom-in" data-wow-delay="0.2s">
					<span class="gallery-border"></span>
					<img src="images/sap/num1.jpg" alt="Image 1">
				</a>
				<a href="images/sap/num2.jpg"  class="gallery-item wow fadeIn" data-effect="mfp-zoom-in" data-wow-delay="0.3s">
					<span class="gallery-border"></span>
					<img src="images/sap/num2.jpg"  alt="Image 2">
				</a>
				<a href="images/sap/num3.jpg" class="gallery-item wow fadeIn" data-effect="mfp-zoom-in" data-wow-delay="0.4s"> 
					<span class="gallery-border"></span>
					<img src="images/sap/num3.jpg" alt="Image 3">
				</a>
				<a href="images/sap/num4.jpg" class="gallery-item wow fadeIn" data-effect="mfp-zoom-in" data-wow-delay="0.5s">
					<span class="gallery-border"></span>
					<img src="images/sap/num4.jpg" alt="Image 4">
				</a>
				<a href="images/sap/num5.jpg" class="gallery-item wow fadeIn" data-effect="mfp-zoom-in" data-wow-delay="0.6s">
					<span class="gallery-border"></span>
					<img src="images/sap/num5.jpg" alt="Image 5">
				</a>
				<a href="images/sap/num6.jpg" class="gallery-item wow fadeIn" data-effect="mfp-zoom-in" data-wow-delay="0.7s">
					<span class="gallery-border"></span>
					<img src="images/sap/num6.jpg" alt="Image 6">
				</a>

				<a href="images/sap/num7.jpg" class="gallery-item" data-effect="mfp-zoom-in">
					<span class="gallery-border"></span>
					<img src="images/sap/num7.jpg" alt="Image 7">
				</a>
				<a href="images/sap/num8.jpg" class="gallery-item" data-effect="mfp-zoom-in">
					<span class="gallery-border"></span>
					<img src="images/sap/num8.jpg" alt="Image 8">
				</a>
			</div>

			<div class="gallery-btn">
				<a href="#" class="def-btn wow fadeInUp" data-wow-delay="0.2s">Show more</a>
			</div>
			
		</div>
	</section>
<!-- AQUI TERMINA LA GALERÍA 1  -->

<!-- AQUI COMIENZA LA GALERÍA 2  -->
<section class="s-gallery" id="s-gallery">
		<div class="container">
			<h2 class="center-title wow fadeIn" data-wow-delay="0.1s">NHSMUN50 - NYC, USA 2024</h2>

			<div class="gallery-wrap">
				<a href="images/sap/ny (1).jpg" class="gallery-item wow fadeIn" data-effect="mfp-zoom-in" data-wow-delay="0.2s">
					<span class="gallery-border"></span>
					<img src="images/sap/ny (1).jpg" alt="Image 1">
				</a>
				<a href="images/sap/ny (2).jpg"  class="gallery-item wow fadeIn" data-effect="mfp-zoom-in" data-wow-delay="0.3s">
					<span class="gallery-border"></span>
					<img src="images/sap/ny (2).jpg"  alt="Image 2">
				</a>
				<a href="images/sap/ny (3).jpg" class="gallery-item wow fadeIn" data-effect="mfp-zoom-in" data-wow-delay="0.4s"> 
					<span class="gallery-border"></span>
					<img src="images/sap/ny (3).jpg" alt="Image 3">
				</a>
				<a href="images/sap/ny (4).jpg" class="gallery-item wow fadeIn" data-effect="mfp-zoom-in" data-wow-delay="0.5s">
					<span class="gallery-border"></span>
					<img src="images/sap/ny (4).jpg" alt="Image 4">
				</a>
				<a href="images/sap/ny (5).jpg" class="gallery-item wow fadeIn" data-effect="mfp-zoom-in" data-wow-delay="0.6s">
					<span class="gallery-border"></span>
					<img src="images/sap/ny (5).jpg" alt="Image 5">
				</a>
				<a href="images/sap/ny (6).jpg" class="gallery-item wow fadeIn" data-effect="mfp-zoom-in" data-wow-delay="0.7s">
					<span class="gallery-border"></span>
					<img src="images/sap/ny (6).jpg" alt="Image 6">
				</a>

				<a href="images/sap/ny (7).jpg" class="gallery-item" data-effect="mfp-zoom-in">
					<span class="gallery-border"></span>
					<img src="images/sap/ny (7).jpg" alt="Image 7">
				</a>
				<a href="images/sap/ny (8).jpg" class="gallery-item" data-effect="mfp-zoom-in">
					<span class="gallery-border"></span>
					<img src="images/sap/ny (8).jpg" alt="Image 8">
				</a>
				<a href="images/sap/ny (9).jpg" class="gallery-item" data-effect="mfp-zoom-in"> 
					<span class="gallery-border"></span>
					<img src="images/sap/ny (9).jpg" alt="Image 9">
				</a>
				<a href="images/sap/ny (10).jpg" class="gallery-item" data-effect="mfp-zoom-in">
					<span class="gallery-border"></span>
					<img src="images/sap/ny (10).jpg" alt="Image 10">
				</a>
				<a href="images/sap/ny (11).jpg" class="gallery-item" data-effect="mfp-zoom-in">
					<span class="gallery-border"></span>
					<img src="images/sap/ny (11).jpg" alt="Image 11">
				</a>
				<a href="images/sap/ny (12).jpg" class="gallery-item" data-effect="mfp-zoom-in">
					<span class="gallery-border"></span>
					<img src="images/sap/ny (12).jpg" alt="Image 12">
				</a>
			</div>

			<div class="gallery-btn">
				<a href="#" class="def-btn wow fadeInUp" data-wow-delay="0.2s">Show more</a>
			</div>

		</div>
	</section>
	<!-- AQUI TERMINA LA GALERÍA 2  -->

<!-- AQUI EMPIEZA LOS PROFES  -->
<section class="s-team" id="s-team">
		<div class="container">
		<h2 class="center-title wow fadeIn" data-wow-delay="0.1s">Our Teachers</h2>
			<div class="about-row">
				<div class="about-left">
					<h2 class="def-title wow fadeInLeft" data-wow-delay="0.2s">About this wonderful and dedicated team</h2>
					<div class="def-desc wow fadeInLeft" data-wow-delay="0.3s">
						<center><strong>Paduamun2024</strong> is a full service building design company with a simple and unique design and construction philosophy. We believe that one building designer will take the job from concept on paper to implementation on your site. Cause; by doing this, you can communicate and work with one person, where you can share your thoughts and ideas to bring them to life in collaboration.
					</div></center>
				</div>
	
				<div class="about-right">
					<img src="images/sap/logomun.png" alt="logomun" class="wow fadeIn" data-wow-delay="0.5s">
				</div>
			</div>

		</div>
	</section>
<!-- AQUI TERMINA LOS PROFES -->

<!-- AQUI EMPIEZA LOS TESTIMONIOS -->

	<section class="s-reviews" id="s-testimonials" style="background-image: url('images/reviews-bg.png');">
		<div class="container">
			<h2 class="center-title color-white wow fadeIn" data-wow-delay="0.1s">What our students say</h2>
			
			<div class="swiper reviews-swiper">
				
				<div class="swiper-wrapper">
				<div class="swiper-slide">
						<div class="reviews-item wow fadeInUp" data-wow-delay="0.3s">
							<div class="reviews-thumb">
								<img src="images/sap/ariana.png" alt="ariana">
							</div>
							
							<div class="reviews-body">
								<div class="reviews-name">Ariana Rodriguez</div>
								<div class="reviews-profi">Student</div>
								<div class="reviews-comment">
								Having had the privilege to represent Peru at NHSMUN in New York was both challenging and rewarding. Through intense debate and preparation, I gained a deeper understanding of global issues and diplomacy. This experience marked the beginning of a journey I wholeheartedly recommend to others.
								</div>
								<div class="reviews-social">
								</div>
							</div>
						</div>
					</div>

					<div class="swiper-slide">
						<div class="reviews-item wow fadeInUp" data-wow-delay="0.2s">
							<div class="reviews-thumb">
								<img src="images/sap/edin.png" alt="Edin">
							</div>

							<div class="reviews-body">
								<div class="reviews-name">Edin Krunoslav</div>
								<div class="reviews-profi">Student</div>
								<div class="reviews-comment">
								As the Peruvian delegate at NHSMUN's UNESCO committee, I addressed "Preserving Education in Conflict Zones," aligning with the UN's mission for future generations. Representing my country was an honor, and engaging in the debate expanded my global perspective through interactions with delegates of diverse cultures and beliefs.
								</div>
								<div class="reviews-social">
								</div>
							</div>
						</div>
					</div>

					<div class="swiper-slide">
						<div class="reviews-item wow fadeInUp" data-wow-delay="0.4s">
							<div class="reviews-thumb">
								<img src="images/sap/ilenka.png" alt="ilenka">
							</div>
							
							<div class="reviews-body">
								<div class="reviews-name">Ilenka Ruiz</div>
								<div class="reviews-profi">Student</div>
								<div class="reviews-comment">
									At NHSMUN in New York, I, alongside my partner Mikelly, represented Peru in the UN-HABITAT committee, engaging in discussions on critical topics like "Increasing Access to Affordable Housing" and "Planning Urban Spaces for Women’s Safety." Our duties involved defending Peru's stance and forging alliances with other nations to shape resolutions. This experience broadened my understanding of global affairs and the intricate workings of Model United Nations conferences.
								</div>
								<div class="reviews-social">
								</div>
							</div>
						</div>
					</div>

					<div class="swiper-slide">
						<div class="reviews-item">
							<div class="reviews-thumb">
								<img src="images/sap/thais.png" alt="alejandra">
							</div>
							
							<div class="reviews-body">
								<div class="reviews-name">Alejandra Thais</div>
								<div class="reviews-profi">Student</div>
								<div class="reviews-comment">
									My trip to New York was incredibly enriching. Meeting the Peruvian ambassador, visiting the UN, and engaging in discussions on the legal status of climate refugees added depth to my MUN experience. Representing Peru, my partner and I proposed innovative solutions, negotiated with delegates, and expanded our understanding of global issues, enhancing my MUN journey with invaluable knowledge and memories.
								</div>
								<div class="reviews-social">
								</div>
							</div>
						</div>
					</div>

					<div class="swiper-slide">
						<div class="reviews-item">
							<div class="reviews-thumb">
								<img src="images/sap/elena.png" alt="elena">
							</div>
							
							<div class="reviews-body">
								<div class="reviews-name">Elena Pascarella</div>
								<div class="reviews-profi">Student</div>
								<div class="reviews-comment">
									I'm Mariagrazia Elena Pascarella Burger, honored to represent Peru in NHSMUN's LEGAL committee. Delving into topics like the legal status of climate change shelters and digital privacy, my partner and I voiced Peru's perspective while forming lasting bonds with delegates worldwide. This enriching experience has equipped me with valuable skills for future Model UN pursuits.
								</div>
								<div class="reviews-social">
								</div>
							</div>
						</div>
					</div>

					<div class="swiper-slide">
						<div class="reviews-item">
							<div class="reviews-thumb">
								<img src="images/sap/astrid.png" alt="astrid">
							</div>
							
							<div class="reviews-body">
								<div class="reviews-name">Astrid Cuti</div>
								<div class="reviews-profi">Student</div>
								<div class="reviews-comment">
									Hey there! I'm Astrid Isabella Cuti, thrilled to have been part of NHSMUN in New York. Initially nervous, with my teacher's support, I found the courage to join the UNESCO committee. Discussing topics like education in conflict zones and safeguarding underwater heritage broadened my knowledge and communication skills, motivating me to encourage others to embrace MUN and overcome their fears.
								</div>
								<div class="reviews-social">
								</div>
							</div>
						</div>
					</div>

				</div>
			
				<div class="swiper-pagination"></div>
			
			</div>

		</div>
	</section>
<!-- AQUI TERMINA LOS TESTIMONIOS -->

<!-- AQUI EMPIEZA EL FORMULARIO E CONTACTO -->
	<section class="s-form" id="s-contact">
		<div class="container">
			<div class="form-row">

				<div class="form-left">
					<h2 class="def-title">Do you have any questions?</h2>
					<div class="def-desc">
						If you have any questions or would like to participate in the 2024 session. Please, feel free to contact us by email or phone call.
					</div>
					<div class="form-image">
						<img src="images/sap/form.jpg" alt="formimg">
					</div>
				</div>

				<div class="form-right">

					<form>
						<input type="text" id="name" placeholder="Your name" required="required" data-validation-required-message="Please enter your name" />
						<input type="text" id="telf" placeholder="Your mobile phone" required="required" data-validation-required-message="Please enter your phone" />
						<input type="text" id="emails" placeholder="Your email" required="required" data-validation-required-message="Please enter your email" />
						<input type="text" id="comment" placeholder="Leave us a message" required="required" data-validation-required-message="Leave us a message" />
						<button class="def-btn form-button btn_send">Send</button>
						<button class="def-btn form-button btn_reniec_disable d-none">Sending....</button>
					</form>
				</div>

			</div>
		</div>
	</section>
<!-- AQUI TERMINA EL FORMULARIO DE CONTACTO -->

<!-- AQUI COMIENZA EL FOOTER  -->
	<footer class="site-footer">
		<div class="container">

			<div class="footer-row">

				<div class="footer-left">
					<div class="footer-desc">
						<strong>#paduamun2024</strong><br>
						making leaders since 2001.
					</div>
				</div>

				<div class="footer-right">
					<div class="footer-nav">
						<h5 class="footer-title">Schedule</h5>
						<ul>
							<li>Monday - Friday : 7:30am - 6:00pm</li>
							<li>Saturday : 7:30am - 1:00pm</li>
							
						</ul>
					</div>

					<div class="footer-nav">
						<h5 class="footer-title">Contact us</h5>
						<div class="footer-info-item">
							<div class="footer-info-icon"><img src="images/location-gray.svg" alt="Location"></div>
							<div> <span> <a type="botton" href="https://maps.app.goo.gl/WCwoZ2ZmfK9EsKjs8" target="_blank" style="text-decoration: none"  class="footer-info-text">1204 Jimenez Pimentel St. Tarapoto, PE</a></span></div>
						</div>
						<a href="tel:+5195070619" class="footer-info-item">
							<div class="footer-info-icon"><img src="images/phone-gray.svg" alt="Phone"></div>
							<div class="footer-info-text">+51 950 706 19</div>
						</a>

						<div class="footer-social">
						<a href="https://www.facebook.com/paduatarapoto" target="_blank">
								<i class="fa fa-facebook" style="font-size:36px"></i>
							</a>
							<a href="https://www.instagram.com/paduamodelun/" target="_blank">
								<i class="fa fa-instagram" style="font-size:36px"></i>
							</a>
						</div>
					</div>
				</div>

			</div>
			
			<div class="footer-copyright">
				<div class="copyright-text">Copyright © 2024 Paduamun. All rights reserved</div>
			</div>

		</div>
	</footer>
<!-- AQUI ACABA EL FOOTER  -->

	<script src="js/jquery-3.7.0.min.js"></script>
	<script src="js/swiper-bundle.min.js"></script>
	<script src="js/magnific-popup.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/script.js"></script>
	

	<!-- SCRIPT PARA ENVIAR MENSAJE Y ALERTAS  -->
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>

        function validar_email(email)
        {
            var regla = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return regla.test(email);

        }
        

        $('body').on('click', '.btn_send', function(){
            event.preventDefault();
             let nombre =  $('#name').val();
			 	 telf    = $('#telf').val();
                 emails   = $('#emails').val();
                 comment  = $('#comment').val();
        
		if(nombre == '' || telf == '' || emails == '' || comment == '')
        {
            Swal.fire({
                        title: "Alert!",
                        text: "Please, fill in the fields!",
                        icon: "warning"
                    });
            return;
        }
         if(!validar_email(emails))
         {
            Swal.fire({
                        title: "Alert!",
                        text: "Wrong email address",
                        icon: "warning"
                    });
            return;
         }
        

        
        $.ajax({
            url     : "<?php echo e(route('send_email')); ?>",
            method  : "POST",
            beforeSend : function(){

                $('.btn_send').prop('disabled', true);
                 $('.btn_send').addClass('d-none');
                $('.btn_reniec_disable').removeClass('d-none');
            },
         
            data    : {nombre: nombre, telf: telf, emails: emails, comment: comment, '_token' : "<?php echo e(csrf_token()); ?>"},
             
            
            success : function(r)
            {
                    if(!r.status)
                    {
                        $('.btn_send').prop('disabled', false);
                        $('.btn_send').removeClass('d-none');
                        $('.btn_reniec_disable').addClass('d-none');

                    }
                    	$('.btn_send').prop('disabled', false);
                        $('.btn_send').removeClass('d-none');
                        $('.btn_reniec_disable').addClass('d-none');

					$('#name').val('');
			 	    $('#telf').val('');
                    $('#emails').val('');
                    $('#comment').val('');

                     Swal.fire({
                        title: "Success!",
                        text: r.message,
                        text: "Your message has been sent",
                        icon: "success"
                    });
                    
            },
            dataType: 'json'
        })

       
        });

    </script>




</body>

</html><?php /**PATH C:\xampp\htdocs\munpadua\resources\views/index.blade.php ENDPATH**/ ?>